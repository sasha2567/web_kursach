<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
            </div><!-- End Of Right -->
            <div class="cleaner"></div>
            
            <div id="templatemo_footer">
	            Copyright © 2015 
	            <a href="<?=base_url();?>">justcooking</a> 
	            | Designed by <a href="http://www.templatemo.com" target="_parent">Free CSS Templates</a>
            </div>
            
            <div class="cleaner"></div>
        </div><!-- End Of Content Area -->    
    </div><!-- End Of Container -->
<!--  Free CSS Templates by TemplateMo.com  -->
</body>
</html>