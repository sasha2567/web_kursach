<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
			<div id="templatemo_right_col">
				<div class="templatemo_post_area">
					<div id="container">
						<h1 id="headerform"><?php if($lang == 'rus') echo 'Такой страници нет'; else echo 'Page not exists';?></h1>
				</div>